Get new tees form S3 and notifies using FCM to android devices.
